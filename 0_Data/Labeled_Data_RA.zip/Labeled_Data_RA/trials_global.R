## Set-up
library("tidyverse")
library("haven")
library("tidyr")
library("janitor")
library("xtable")
library("lfe")
library("survey")
library("foreign")
library("gridExtra")
library("diagis")
library("forstringr")

root <- "//rb.win.frb.org/b1/NYRESAN/Community/HouseholdPolicy/Emanuel_RA/ClinicalTrials/"
root <- "/san/Community/HouseholdPolicy/Emanuel_RA/ClinicalTrials/"

raw_path <- file.path(root, "/RawData/")
raw_nhanes_path <- file.path(root, "/RawData/NHANES/")
data_path <- file.path(root, "/Data/")
output_path <- file.path(root, "/Output/")

#### Clean study identifying information ####
study <- read_delim(paste0(raw_path, "/AACT/studies.txt"),
                    delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(baseline_population = str_to_lower(baseline_population),
         brief_title = str_to_lower(brief_title),
         official_title = str_to_lower(official_title),
         preg_population = ifelse(str_detect(baseline_population, "pregnan(cy|t)") | 
                                    str_detect(baseline_population, "gestat(e|tion)") |
                                    str_detect(baseline_population, "cesarean"), 1,0),
         preg_population = ifelse(is.na(baseline_population), 0, preg_population),
         preg_btitle = ifelse(str_detect(brief_title, "pregnan(cy|t)") | 
                                str_detect(brief_title, "gestat(e|tion)") |
                                str_detect(brief_title, "cesarean"), 1,0),
         preg_btitle = ifelse(is.na(brief_title), 0, preg_btitle), 
         preg_otitle = ifelse(str_detect(official_title, "pregnan(cy|t)") | 
                                str_detect(official_title, "gestat(e|tion)") |
                                str_detect(official_title, "cesarean"), 1,0),
         preg_otitle = ifelse(is.na(official_title), 0, preg_otitle))

study <- study %>%
  group_by(nct_id) %>%
  summarize(preg_population = max(preg_population, na.rm=T),
            preg_btitle = max(preg_btitle, na.rm=T),
            preg_otitle = max(preg_otitle, na.rm=T)) %>%
  ungroup()

study <- study %>%
  mutate(preg_population = ifelse(preg_population < 0, NA, preg_population),
         preg_btitle  = ifelse(preg_btitle < 0, NA, preg_btitle),
         preg_otitle = ifelse(preg_otitle < 0, NA, preg_otitle))

study %>% select(preg_population) %>% table()
study %>% select(preg_btitle) %>% table()
study %>% select(preg_otitle) %>% table()


#### Clean study locations ####
countries <- read_delim(paste0(raw_path, "/AACT/countries.txt"),
                        delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(usa = ifelse(name == "United States",1,0)) %>%
  group_by(nct_id) %>%
  summarize(usa = max(usa, na.rm=T)) %>%
  ungroup() %>%
  mutate(usa = ifelse(usa == -Inf,0,usa))

table(countries$usa)


#### Clean study keywords ####
keywords <- read_delim(paste0(raw_path, "/AACT/keywords.txt"),
                       delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(downcase_name = str_replace_all(downcase_name, "pregncy", "pregnancy"),
         downcase_name = str_replace_all(downcase_name, "pregnany", "pregnancy"),
         downcase_name = str_replace_all(downcase_name, "pregnt", "pregnant")) %>%
  mutate(preg_keywords = ifelse(str_detect(downcase_name, "pregnan(t|cy|ies)") |
                                  str_detect(downcase_name, "gestat(e|ing|ion)") |
                                  str_detect(downcase_name, "cesarean"),1,0),
         preg_keywords = ifelse(is.na(downcase_name),NA,preg_keywords)) %>%
  group_by(nct_id) %>%
  summarize(preg_keywords = max(preg_keywords, na.rm = T))

keywords %>% select(preg_keywords) %>% table()

keywords %>% select(preg_keywords) %>% table()


#### Clean randomization and research design ####
randomized <- read_delim(paste0(raw_path, "/AACT/designs.txt"),
                         delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(randomized = ifelse(allocation == "Randomized",1,0)) %>%
  group_by(nct_id) %>%
  summarize(randomized = max(randomized, na.rm=T),
            intervention_model = intervention_model,
            primary_purpose = primary_purpose,
            masking = masking) %>%
  ungroup()
randomized <- randomized %>%
  mutate(randomized = ifelse(randomized < 0, 0, randomized))

#### Clean research design groups ####
groups <- read_delim(paste0(raw_path, "/AACT/design_groups.txt"),
                     delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(description = str_to_lower(description)) %>%
  mutate(description = str_replace_all(description, "pregncy", "pregnancy"),
         description = str_replace_all(description, "pregnany", "pregnancy"),
         description = str_replace_all(description, "pregnt", "pregnant")) %>%
  mutate(preg_group = ifelse((str_detect(description, "pregnan(t|cy|ies)") |
                                str_detect(description, "gestat(e|ing|ion)") | 
                                str_detect(description, "cesarean")),1,0),
         preg_group = ifelse(is.na(description),NA,preg_group)) %>%
  group_by(nct_id) %>%
  summarize(preg_group = max(preg_group, na.rm = T)) %>%
  mutate(preg_group = ifelse(preg_group < 0,NA,preg_group))

table(groups$preg_group)

#### Clean interventions ####
drug_intervention <- read_delim(paste0(raw_path, "/AACT/interventions.txt"),
                                delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(drug = ifelse(intervention_type == "Drug",1,0)) %>%
  group_by(nct_id) %>%
  summarize(drug = max(drug, na.rm=T))

#### Clean conditions ####
conditions <- read_delim(paste0(raw_path, "/AACT/conditions.txt"),
                         delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(downcase_name = str_replace_all(downcase_name, "pregncy", "pregnancy"),
         downcase_name = str_replace_all(downcase_name, "pregnany", "pregnancy"),
         downcase_name = str_replace_all(downcase_name, "pregnt", "pregnant"),
         downcase_name = str_replace_all(downcase_name, "preclampsia", "preeclampsia"),
         downcase_name = str_replace_all(downcase_name, "pre-eclampsia", "preeclampsia"),
         downcase_name = str_replace_all(downcase_name, "caesarean", "cesarean"),
         downcase_name = str_replace_all(downcase_name, "cesaraen", "cesarean")) %>%
  mutate(preg_condition = ifelse((str_detect(downcase_name, "pregnan(t|cy|ies)") |
                                    str_detect(downcase_name, "gestat(e|ing|ion)") |
                                    str_detect(downcase_name, "labor") |
                                    str_detect(downcase_name, "preeclampsia")),1,0),
         preg_condition = ifelse(is.na(downcase_name),NA,preg_condition)) %>%
  group_by(nct_id) %>%
  summarize(preg_condition = max(preg_condition, na.rm = T))

table(conditions$preg_condition)

#### Load eligibilities and join all study variables ####
elig <- read_delim(paste0(raw_path, "/AACT/eligibilities.txt"),
                   delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  left_join(countries, by = join_by(nct_id)) %>%
  left_join(keywords, by = join_by(nct_id)) %>%
  left_join(randomized, by = join_by(nct_id)) %>%
  left_join(drug_intervention, by = join_by(nct_id)) %>%
  left_join(conditions, by = join_by(nct_id)) %>%
  left_join(groups, by = join_by(nct_id)) %>%
  left_join(study, by = join_by(nct_id))


#### Additional study summary, brief and detailed ####
# summary_brief <- read_delim(paste0(raw_path, "/AACT/brief_summaries.txt"),
#                             delim = "|", escape_double = FALSE, trim_ws = TRUE)
# summary_detail <- read_delim(paste0(raw_path, "/AACT/detailed_descriptions.txt"),
#                    delim = "|", escape_double = FALSE, trim_ws = TRUE)


#### Clean eligibility ####
elig <- elig %>%
  mutate(criteria = str_to_lower(criteria),
         min_age = parse_number(minimum_age),
         max_age = parse_number(maximum_age),
         min_age_unit = case_when(str_detect(minimum_age, "Years") ~ 1,
                                  str_detect(minimum_age, "Months") ~ 1/12,
                                  str_detect(minimum_age, "Weeks") ~ 1/52,
                                  str_detect(minimum_age, "Days") ~ 1/365,
                                  str_detect(minimum_age, "Hours") ~ 1/8760),
         max_age_unit = case_when(str_detect(maximum_age, "Years") ~ 1,
                                  str_detect(maximum_age, "Months") ~ 1/12,
                                  str_detect(maximum_age, "Weeks") ~ 1/52,
                                  str_detect(maximum_age, "Days") ~ 1/365,
                                  str_detect(maximum_age, "Hours") ~ 1/8760),
         min_age = min_age * min_age_unit,
         max_age = max_age * max_age_unit,
         criteria = str_replace(criteria, "entry criteria", "inclusion criteria"),
         criteria = str_replace(criteria, "enrollment criteria", "inclusion criteria"),
         criteria = str_replace(criteria, "exclusions criteria", "exclusion criteria"),
         criteria = str_replace(criteria, "exclusions(:|~)", "exclusion criteria"),
         criteria = str_replace(criteria, "exclusion(:|~)", "exclusion criteria"),
         focal_trials_global = ifelse(randomized == 1 & drug == 1, 1,0)) %>%
  mutate(criteria = str_replace_all(criteria, "pregncy", "pregnancy"),
         criteria = str_replace_all(criteria, "pregnany", "pregnancy"),
         criteria = str_replace_all(criteria, "pregnt", "pregnant"))

elig <- elig %>%
  mutate(min_age = ifelse(is.na(min_age),0,min_age),
         max_age = ifelse(is.na(max_age),100,max_age))


focal_ncts <- elig %>%
  filter(focal_trials_global == 1) %>%
  select(nct_id) %>%
  unique()


## Find pregnant-enrolling studies in eligibility
elig <- elig %>%
  mutate(childbearing_age = ifelse((max_age > 18 & !is.na(max_age)) & 
                                     (min_age < 45 & !is.na(min_age)), 1, 0),
         women_included = ifelse(gender == "Female" | gender == "All",1,0),
         format_inex = ifelse(str_detect(criteria, "inclusion criteria") &
                                str_detect(criteria, "exclusion criteria"),1,0),
         format_inonly = ifelse(str_detect(criteria, "inclusion criteria") &
                                  !str_detect(criteria, "exclusion criteria"),1,0),
         format_exonly = ifelse(str_detect(criteria, "exclusion criteria")
                                & !str_detect(criteria, "inclusion criteria"),1,0))

elig %>%
  select(childbearing_age) %>%
  table()

elig %>%
  select(women_included) %>%
  table()

elig %>% 
  filter(women_included & childbearing_age & usa) %>%
  count()

elig %>% 
  filter(women_included == 1 & childbearing_age == 1 &
           focal_trials_global == 1 & !is.na(gender_description)) %>%
  select(gender_description) %>%
  count()



#### Indicating pregnant studies from gender description ####
elig <- elig %>%
  mutate(gender_description = str_to_lower(gender_description)) %>%
  mutate(preg_genderdesc = ifelse(
    (str_detect(gender_description, "pregnan(t|cy)( women| woman| adult| female| people| indiv| subject| patient| part|-related| undergoing cesarean)") | 
       str_detect(gender_description, "(are|to be|must be|can be|plan to be|being|at the end of the|
               |(confirmed |)singleton|being|with twin|evidence of|able to become|currently|able to get|
               |eligible if|want to get|during|weeks of|requires|unique to|actively) preg") |
       str_detect(gender_description, "pregnancy(| study| is a required)") |
       str_detect(gender_description, "cesarean")) &
      !(str_detect(gender_description, "no(n|t)(-| |)pregnant") | nct_id == "NCT03674177" | nct_id == "NCT06133803")
    ,1,0))


elig %>% filter(!is.na(gender_description) & childbearing_age == 1 &
                  women_included == 1 & focal_trials_global == 1) %>% select(preg_genderdesc) %>% table()  

elig %>% filter(!is.na(gender_description) & childbearing_age == 1 &
                  women_included == 1) %>% select(preg_genderdesc) %>% table()  ## DONE
### 185 mostly positives to manually code


# Criteria

elig_inex <- elig %>%
  filter(focal_trials_global == 1 & format_inex == 1) %>%
  mutate(inclusion = str_extract_part(criteria, "exclusion criteria", before = T),
         exclusion = str_extract_part(criteria, "exclusion criteria", before = F))

## FIRST PASS
elig_inex <- elig_inex %>%
  mutate(preg_criteria = case_when(
    (str_detect(criteria,"singleton (pregnancy|gestation|fetus)")) ~ 1,
    (str_detect(criteria,"fetus at term")) ~ 1,
    (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ 0,
    (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
                (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ 0,
    (str_detect(inclusion,"spermicid")) ~ 0,
    (str_detect(exclusion,"( |~|,|:)pregnan(t|cy)")) ~ 0,
    (str_detect(criteria,"(not currently|should not be|without|not to be|test negative for|cannot get|cannot become
                |must not be|risk for|risk of|not to attempt|not capable of becoming) pregnan(t|cy)")) ~ 0,
    (str_detect(criteria, "(prevent|avoid) pregnancy")) ~ 0,
    (str_detect(inclusion,"non-childbearing")) ~ 0,
    (str_detect(criteria,"neither pregnant nor breastfeeding")) ~ 0,
    (str_detect(criteria, "(negative|negative result for a|serum|urine|serum or urine|screening serum) pregnancy test")) ~ 0,
    (str_detect(criteria, "negative (serum|urine|test for pregnancy)")) ~ 0,
    (str_detect(criteria, "no pregnant (females|women|woman)")) ~ 0,
    (str_detect(exclusion,"( |~|,|:)pregnan(t|cy)")) ~ 0,
    (str_detect(exclusion,"pregnant and childbearing")) ~ 0,
    (str_detect(criteria,"(have|take) a pregnancy test")) ~ 0,
    (str_detect(inclusion,"pregnancy test is negative")) ~ 0,
    (str_detect(inclusion,"no pregnan(t|cy) potential")) ~ 0,
    (str_detect(inclusion,"contraceptive regimen")) ~ 0,
    (str_detect(criteria,"be (taking|using) contracep")) ~ 0,
    (str_detect(criteria,"use (non-hormonal|)contracep")) ~ 0,
    (str_detect(inclusion, "(first|1st|second|2nd|third|3rd) trimester")) ~ 1,
    (str_detect(inclusion,"gestat(e|ing|ion)")) ~ 1,
    (str_detect(inclusion,"cesarean")) ~ 1,
    (str_detect(exclusion,"female-pregnan")) ~ 0,
    (str_detect(exclusion,"current(ly|) pregnan(t|cy)")) ~ 0,
    (str_detect(exclusion,"pregnant or (lactating|breastfeeding|nursing)")) ~ 0,
    (str_detect(exclusion,"\\(pregnan(cy|t)")) ~ 0,
    (str_detect(exclusion,"pregnant women")) ~ 0,
    (str_detect(exclusion,"nursing/pregnan(t|cy)")) ~ 0,
    (str_detect(inclusion,"no(n|t)(-| |)pregnant")) ~ 0,
    (str_detect(inclusion,"( |~|:)pregnan(t|cy)")) ~ 1,
    (str_detect(criteria,"non(-|)pregnant")) ~ 0,
    (str_detect(criteria,"non(-|)pregnant")) ~ 0,
    T ~ NA))

# elig_inex %>%
#   filter(is.na(preg_criteria) & !is.na(criteria) &
#            (preg_population == 1 | preg_genderdesc == 1 | preg_group == 1 | preg_keywords == 1 | preg_btitle == 1 | preg_otitle == 1)) %>%
#   select(nct_id, inclusion, exclusion, preg_genderdesc, preg_criteria, preg_group, 
#          preg_population, preg_btitle, preg_otitle) %>%
#   View()


elig_inexNAs <- elig_inex %>%
  mutate(preg_genderdesc = ifelse(is.na(preg_genderdesc), 0, preg_genderdesc),
         preg_criteria = ifelse(is.na(preg_criteria), 0, preg_criteria),
         preg_group = ifelse(is.na(preg_group), 0, preg_group),
         preg_condition = ifelse(is.na(preg_condition), 0, preg_condition),
         preg_population = ifelse(is.na(preg_population), 0, preg_population),
         preg_btitle = ifelse(is.na(preg_btitle), 0, preg_btitle),
         preg_otitle = ifelse(is.na(preg_otitle), 0, preg_otitle),
         preg_keywords = ifelse(is.na(preg_keywords), 0, preg_keywords))

elig_inex$preg_sums <- rowSums(elig_inexNAs[,c("preg_genderdesc", "preg_criteria",
                                               "preg_group", "preg_condition", "preg_population",
                                               "preg_btitle", "preg_otitle", "preg_keywords")])



elig_inex %>% 
  select(preg_sums) %>% table()


elig_inex <- elig_inex %>%
  mutate(preg_enrolled = ifelse(preg_sums >= 3,1,0),
         preg_related = ifelse(preg_btitle == 1 | preg_otitle == 1 | preg_condition == 1 | preg_group == 1 | 
                                 preg_population == 1 | preg_enrolled ==1,1,0)) %>%
  mutate(preg_enrolled = case_when(
    
    TRUE ~ preg_enrolled))





# elig_inex %>%
#   filter(preg_enrolled == 0 & preg_sums > 1) %>%
#   select(nct_id, criteria, exclusion, preg_keywords, preg_condition, preg_population, preg_group, preg_genderdesc, preg_sums) %>%
#   View()



elig_lessformat <- elig %>%
  filter(focal_trials_global == 1 & format_inex == 0) %>%
  mutate(exclusion = str_extract_part(criteria, "exclusion criteria", before = F)) %>%
  mutate(preg_criteria = case_when(
    (str_detect(criteria,"singleton (pregnancy|gestation|fetus)")) ~ 1,
    (str_detect(criteria,"fetus at term")) ~ 1,
    (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ 0,
    (str_detect(criteria,"(not currently|should not be|without|not to be|test negative for|cannot be|cannot get|cannot become|
                |must not be|risk for|risk of|not to attempt|not capable of becoming|not|non) pregnan(t|cy)")) ~ 0,
    (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
                (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ 0,
    (str_detect(criteria,"spermicid")) ~ 0,
    (str_detect(exclusion,"( |~|,|:)pregnan(t|cy)")) ~ 0,
    (str_detect(criteria,"following vaginal or cesarean")) ~ 0,
    (str_detect(criteria,"cesarean")) ~ 1,
    (str_detect(criteria, "(prevent|avoid) pregnancy")) ~ 0,
    (str_detect(criteria,"non-childbearing")) ~ 0,
    (str_detect(criteria,"neither pregnant nor breastfeeding")) ~ 0,
    (str_detect(criteria, "(negative|negative result for a|serum|urine|serum or urine|screening serum) pregnancy test")) ~ 0,
    (str_detect(criteria, "negative (serum|urine|test for pregnancy)")) ~ 0,
    (str_detect(criteria, "(men and|)no(n|n-| )pregnant (|females|women|woman)")) ~ 0,
    (str_detect(criteria, "(first|1st|second|2nd|third|3rd) trimester")) ~ 1,
    (str_detect(exclusion,"( |~|,|:)pregnan(t|cy)")) ~ 0,
    (str_detect(exclusion,"female-pregnan")) ~ 0,
    (str_detect(exclusion,"current(ly|) pregnan(t|cy)")) ~ 0,
    (str_detect(exclusion,"pregnant or (lactating|breastfeeding|nursing)")) ~ 0,
    (str_detect(exclusion,"\\(pregnan(cy|t)")) ~ 0,
    (str_detect(exclusion,"pregnant women")) ~ 0,
    (str_detect(exclusion,"nursing/pregnan(t|cy)")) ~ 0,
    (str_detect(criteria,"( |~|,|:)pregnan(t|cy)")) ~ 1,
    (str_detect(criteria,"non(-|)pregnant")) ~ 0,
    T ~ NA))


elig_lessformat %>%
  select(preg_criteria) %>%
  table()



elig_lessformatNAs <- elig_lessformat %>%
  mutate(preg_genderdesc = ifelse(is.na(preg_genderdesc), 0, preg_genderdesc),
         preg_criteria = ifelse(is.na(preg_criteria), 0, preg_criteria),
         preg_group = ifelse(is.na(preg_group), 0, preg_group),
         preg_condition = ifelse(is.na(preg_condition), 0, preg_condition),
         preg_population = ifelse(is.na(preg_population), 0, preg_population),
         preg_btitle = ifelse(is.na(preg_btitle), 0, preg_btitle),
         preg_otitle = ifelse(is.na(preg_otitle), 0, preg_otitle),
         preg_keywords = ifelse(is.na(preg_keywords),0,preg_keywords))

elig_lessformat$preg_sums <- rowSums(elig_lessformatNAs[,c("preg_genderdesc", "preg_criteria",
                                                           "preg_group", "preg_condition", "preg_population",
                                                           "preg_btitle", "preg_otitle", "preg_keywords")])

elig_lessformat %>% 
  select(preg_sums) %>% table()

# elig_lessformat %>% 
#   filter(preg_sums > 1) %>%                 # check if == 1
#   select(nct_id, criteria, exclusion, preg_keywords, preg_condition, 
#          preg_population, preg_group, preg_genderdesc, preg_sums) %>%
#   View()


elig_lessformat <- elig_lessformat %>%
  mutate(preg_enrolled = ifelse(preg_sums >= 3,1,0),
         preg_related = ifelse(preg_btitle == 1 | preg_otitle == 1 | preg_condition == 1 | 
                                 preg_group == 1 | preg_population == 1 | preg_genderdesc == 1 |
                                 preg_enrolled == 1,1,0)) 



focal_trials_global <- rbind(elig_inex %>% 
                               select(-c(`inclusion`)), 
                             elig_lessformat)

#### Join on conditions ####
# Conditions
conditions <- read_delim(paste0(raw_path, "/AACT/conditions.txt"),
                         delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  mutate(downcase_name = str_replace_all(downcase_name, "pregncy", "pregnancy"),
         downcase_name = str_replace_all(downcase_name, "pregnany", "pregnancy"),
         downcase_name = str_replace_all(downcase_name, "pregnt", "pregnant"),
         downcase_name = str_replace_all(downcase_name, "preclampsia", "preeclampsia"),
         downcase_name = str_replace_all(downcase_name, "pre-eclampsia", "preeclampsia"),
         downcase_name = str_replace_all(downcase_name, "caesarean", "cesarean"),
         downcase_name = str_replace_all(downcase_name, "cesaraen", "cesarean"))

conditions <- arrange(conditions, nct_id, id)

conditions <- conditions %>%
  group_by(nct_id) %>%
  mutate(n = row_number()) %>%
  ungroup()
# 
# conditions_wide <- conditions %>%
#   pivot_wider(id_cols = c(nct_id),
#               names_prefix = "cond",
#               names_from = c(n),
#               values_from = c(downcase_name))

conditions_vars <- conditions %>%
  group_by(nct_id) %>%
  mutate(cond_combo = paste0(downcase_name, collapse = " ~ ")) %>%
  ungroup() %>%
  select(nct_id, cond_combo) %>%
  unique() %>%
  mutate(anx_dep = ifelse(str_detect(cond_combo, "depress") |
                            str_detect(cond_combo, "anxi"),1,0),
         asthma = ifelse(str_detect(cond_combo, "asthma"),1,0),
         hypothyroid = ifelse(str_detect(cond_combo, "hypothyroid") |
                                str_detect(cond_combo, "underactive thyroid"),1,0),
         hypertension = ifelse((str_detect(cond_combo, "hypertension") |
                                  str_detect(cond_combo, "hbp") |
                                  str_detect(cond_combo, "high blood pressure")) &
                                 !str_detect(cond_combo, "ocular hypertension"),1,0))


study <- read_delim(paste0(raw_path, "/AACT/studies.txt"),
                    delim = "|", escape_double = FALSE, trim_ws = TRUE) %>%
  select(nct_id, brief_title, enrollment, number_of_arms, overall_status, 
         completion_date, study_first_submitted_date) %>%
  unique()


focal_trials_global <- left_join(focal_trials_global, conditions_vars, by=join_by(nct_id)) %>%
  left_join(study, by=join_by(nct_id))

focal_trials_global <- focal_trials_global %>%
  mutate(dt_submitted = parse_date_time(study_first_submitted_date, c("Y-m-d", "Y-m")),
         yr_submitted = year(study_first_submitted_date),
         dt_complete = parse_date_time(completion_date, c("Y-m-d", "Y-m")),
         yr_complete = year(dt_complete))


range(focal_trials_global$dt_submitted)
range(focal_trials_global$yr_submitted)


## Reassign missed preg_sum >= 3 to preg_enrolled == 1
focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = ifelse(preg_sums >= 3, 1, preg_enrolled))


## Assign pregnancy enrollment with near-certainty based on key terms
focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = case_when(str_detect(cond_combo, "pregnan(cy|t)") ~ 1,
                                   str_detect(criteria, "singleton preg") ~ 1,
                                   str_detect(criteria, "pregnancy duration") ~ 1,
                                   str_detect(criteria, "paturient") ~ 1,
                                   (str_detect(criteria, "gestational (age|week)") &
                                      !str_detect(criteria, "neonate") & !str_detect(criteria, "infant")) ~ 1,
                                   str_detect(criteria, "c(ae)sarean") ~ 1,
                                   str_detect(criteria, "weeks' gestation") ~ 1,
                                   str_detect(cond_combo, "labor") ~ 1,
                                   str_detect(cond_combo, "gestation") ~ 1,
                                   str_detect(cond_combo, "cesarean") ~ 1,
                                   TRUE ~ preg_enrolled))

## Set trials about abortion/IVF/non-viable fetus to pregnancy-excluding
focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = case_when(max_age <= 13 ~ 0,
                                   (str_detect(criteria, "(abortion|termination)") | str_detect(criteria, "non(-|)viable fetus") |
                                      str_detect(criteria, "no fetal heartbeat") | str_detect(criteria, "undesired pregnancy")) ~ 0,
                                   (str_detect(cond_combo, "(abortion|terminiation)") | str_detect(cond_combo, "non(-|)viable fetus") |
                                      str_detect(cond_combo, "no fetal heartbeat") | str_detect(cond_combo, "undesired pregnancy")) ~ 0,
                                   (str_detect(criteria, "ivf") | str_detect(criteria, "in vitro fertili")) ~ 0,
                                   (str_detect(cond_combo, "ivf") | str_detect(cond_combo, "in vitro fertili")) ~ 0,
                                   (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ 0,
                                   (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
                                 (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ 0,
                                   (str_detect(criteria,"spermicid")) ~ 0,
                                   str_detect(criteria, "infertil(e|ity)") ~ 0,
                                   str_detect(cond_combo, "infertil(e|ity)") ~ 0,
                                   str_detect(criteria, "post(-|)partum") ~ 0,
                                   TRUE ~ preg_enrolled))

{
  ## Checked cases where criteria string detect triggers but all other pregnancy indicators == 0
# focal_trials_global <- focal_trials_global %>%
#   mutate(preg_enrolled = case_when((nct_id == "NCT03152877" | nct_id == "NCT00957593" | nct_id == "NCT04496908" | nct_id == "NCT00610688" |
#                                       nct_id == "NCT01869361" | nct_id == "NCT03954990" | nct_id == "NCT00641784" | nct_id == "NCT02536352" |
#                                       nct_id == "NCT03171480" | nct_id == "NCT02565485" | nct_id == "NCT00402389" | nct_id == "NCT03348683" |
#                                       nct_id == "NCT02454296" | nct_id == "NCT03022526" | nct_id == "NCT02115256" | nct_id == "NCT03202550" |
#                                       nct_id == "NCT03305575" | nct_id == "NCT00306462" | nct_id == "NCT03106753" | nct_id == "NCT05068661" |
#                                       nct_id == "NCT03140293" | nct_id == "NCT00377832" | nct_id == "NCT01402050" | nct_id == "NCT00719537" |
#                                       nct_id == "NCT00871442" | nct_id == "NCT00201643" | nct_id == "NCT05047211" | nct_id == "NCT04578015" |
#                                       nct_id == "NCT04479072" | nct_id == "NCT05782816" | nct_id == "NCT01866488" | nct_id == "NCT02505984" |
#                                       nct_id == "NCT00811057") ~ 1,
#                                    TRUE ~ preg_enrolled))




## Checked cases with triggered pregnancy string detects on any variable (preg_related == 1)
# focal_trials_global <- focal_trials_global %>%
#   mutate(preg_enrolled = case_when(
#     (nct_id == "NCT05973747" | nct_id == "NCT02806024" |
#        nct_id == "NCT00946088" | nct_id == "NCT00771511" | nct_id == "NCT00115687" | nct_id == "NCT02141555" |
#        nct_id =="NCT04294069" | nct_id == "NCT04704024" | nct_id == "NCT01011634" | nct_id == "NCT02277782" | 
#        nct_id == "NCT03433040" | nct_id == "NCT01734161" | nct_id == "NCT02265965" | nct_id == "NCT00086177" |
#        nct_id == "NCT01307839" | nct_id == "NCT02314728" | nct_id == "NCT04278651" | nct_id == "NCT00458003" |
#        nct_id == "NCT04158830" | nct_id == "NCT03335293" | nct_id == "NCT03640507" | nct_id == "NCT03567707" |
#        nct_id == "NCT00468520" | nct_id == "NCT02571439" | nct_id == "NCT00787176" | nct_id == "NCT02213094" |
#        nct_id == "NCT01828697" | nct_id == "NCT04615351" | nct_id == "NCT02960113" | nct_id == "NCT00432991" |
#        nct_id == "NCT03105661" | nct_id == "NCT00293735" | nct_id == "NCT00615550" | nct_id == "NCT05692245" |
#        nct_id == "NCT03117660" | nct_id == "NCT00743210" | nct_id == "NCT02247726" | nct_id == "NCT02487771" |
#        nct_id == "NCT01216410" | nct_id == "NCT01566630" | nct_id == "NCT01621230" | nct_id == "NCT02872935" |
#        nct_id == "NCT01840228" | nct_id == "NCT02573597" | nct_id == "NCT04908982" | nct_id == "NCT03052270" |
#        nct_id == "NCT05132829" | nct_id == "NCT02101047" | nct_id == "NCT00194987" | nct_id == "NCT02408315" |
#        nct_id == "NCT05487196" | nct_id == "NCT00404768" | nct_id == "NCT00762554" | nct_id == "NCT01329016" |
#        nct_id == "NCT00163020" | nct_id == "NCT03029702" | nct_id == "NCT02509312" | nct_id == "NCT03918850" |
#        nct_id == "NCT06036446" | nct_id == "NCT01801475" | nct_id == "NCT01733212" | nct_id == "NCT05676476" |
#        nct_id == "NCT01812239" | nct_id == "NCT03245970" | nct_id == "NCT02121184" | nct_id == "NCT01519765" |
#        nct_id == "NCT00583011" | nct_id == "NCT05912517" | nct_id == "NCT00514618" | nct_id == "NCT04349124" |
#        nct_id == "NCT04532801" | nct_id == "NCT05069012" | nct_id == "NCT00151346" | nct_id == "NCT03117660" | 
#        nct_id == "NCT01733212" | nct_id == "NCT00115687" | nct_id == "NCT00135707" | nct_id == "NCT03176459") ~ 1,
#     (nct_id == "NCT02141555" | nct_id == "NCT01011634" | nct_id == "NCT04153513") ~ 0,
#     (nct_id != "NCT03735433" & nct_id != "NCT00011362" & nct_id != "NCT04379518" & nct_id != "NCT00932321" & nct_id != "NCT02755090" & nct_id != "NCT01224509" & nct_id != "NCT00186082" &
#        nct_id != "NCT04455958" & nct_id != "NCT00065858" & nct_id != "NCT01959464" & nct_id != "NCT01286051" & nct_id != "NCT03460756" & nct_id != "NCT03228394" & nct_id != "NCT03878446" & 
#        nct_id != "NCT00337792" & nct_id != "NCT00005775" & nct_id != "NCT02447029" & nct_id != "NCT04830735" & nct_id != "NCT01857310" & nct_id != "NCT03785366" & nct_id != "NCT04665115" & 
#        nct_id != "NCT04532372" & nct_id != "NCT00520455" & nct_id != "NCT00487084" & nct_id != "NCT01484015" & nct_id != "NCT01539720" & nct_id != "NCT01044862" & nct_id != "NCT05695352" &
#        nct_id != "NCT00357526" & nct_id != "NCT02817464" & nct_id != "NCT00068861" & nct_id != "NCT00324324" & nct_id != "NCT00003702" & preg_enrolled == 0 & preg_condition == 1) ~ 1,
#     (nct_id == "NCT02913495" | nct_id == "NCT01472549" | nct_id == "NCT00153517" | nct_id == "NCT02044991" | nct_id == "NCT00093938" | nct_id == "NCT00133029" | nct_id == "NCT06029673" |
#        nct_id == "NCT03677830" | nct_id == "NCT02956616" | nct_id == "NCT03176459" | nct_id == "NCT02063568" | nct_id == "NCT00439374" | nct_id == "NCT01862991" | nct_id == "NCT04232306" |
#        nct_id == "NCT00724594"  | nct_id == "NCT01047748"  | nct_id == "NCT03377595"  | nct_id == "NCT01775605" | nct_id == "NCT02490345" | nct_id == "NCT03387579" | nct_id == "NCT03139240") ~ 1,
#     TRUE ~ preg_enrolled))




# focal_trials_global %>% filter(women_included == 1 & childbearing_age == 1 & preg_policy == "NotMentioned" &
#                           (str_detect(criteria, "pregnan") | str_detect(criteria, "birth control"))) %>% View()


# focal_trials_global %>% filter(preg_enrolled == 0 & preg_related == 1) %>% select(nct_id, criteria, cond_combo) %>% View()






# #### Pregnant policy variable (included, excluded, not mentioned) ####
# focal_trials_global <- focal_trials_global %>%
#   mutate(preg_policy = case_when((preg_criteria == 1 | preg_enrolled == 1) ~ "Included",
#                                  preg_criteria == 0 ~ "Excluded",
#                                  is.na(preg_criteria)  ~ "NotMentioned"))
# 
# ## Filtering out abortion/IVF/non-viable fetus studies to "Excluded"
# focal_trials_global <- focal_trials_global %>%
#   mutate(preg_policy = case_when((str_detect(criteria, "(abortion|termination)") | str_detect(criteria, "non(-|)viable fetus") |
#                                     str_detect(criteria, "no fetal heartbeat") | str_detect(criteria, "undesired pregnancy")) ~ "Excluded",
#                                  (str_detect(cond_combo, "(abortion|terminiation)") | str_detect(cond_combo, "non(-|)viable fetus") |
#                                     str_detect(cond_combo, "no fetal heartbeat") | str_detect(cond_combo, "undesired pregnancy")) ~ "Excluded",
#                                  (str_detect(criteria, "ivf") | str_detect(criteria, "in vitro fertili")) ~ "Excluded",
#                                  (str_detect(cond_combo, "ivf") | str_detect(cond_combo, "in vitro fertili")) ~ "Excluded",
#                                  (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ "Excluded",
#                                  (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
#                                  (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ "Excluded",
#                                  (str_detect(criteria,"spermicid")) ~ "Excluded",
#                                  TRUE ~ preg_policy))
# 
# 
# ## Assign pregnancy policy with near-certainty based on key terms
# focal_trials_global <- focal_trials_global %>%
#   mutate(preg_policy = case_when(max_age <= 13 ~ "Excluded",
#                                    str_detect(criteria, "singleton") ~ "Included",
#                                    str_detect(criteria, "paturient") ~ "Included",
#                                    str_detect(criteria, "gestational (age|week)") ~ "Included",
#                                    str_detect(criteria, "c(ae)sarean") ~ "Included",
#                                    str_detect(criteria, "weeks' gestation") ~ "Included",
#                                    str_detect(criteria, "infertil(e|ity)") ~ "Excluded",
#                                    TRUE ~ preg_policy))
# 

#### Manual sorting ####


## Output studies for handcheck - DO NOT RUN WITHOUT "_SAFETY" IN FILENAME, WILL OVERWRITE MANUAL ASSIGNMENTS

# 
# focal_trials_global %>%
#   filter(usa == 0 & preg_sums > 0 & preg_sums < 3) %>%
#   mutate(pregfilter = case_when((str_detect(criteria, "(abortion|termination)") | str_detect(criteria, "non(-|)viable fetus") |
#                                    str_detect(criteria, "no fetal heartbeat") | str_detect(criteria, "undesired pregnancy")) ~ 0,
#                                 (str_detect(cond_combo, "(abortion|terminiation)") | str_detect(cond_combo, "non(-|)viable fetus") |
#                                    str_detect(cond_combo, "no fetal heartbeat") | str_detect(cond_combo, "undesired pregnancy")) ~ 0,
#                                 (str_detect(criteria, "ivf") | str_detect(criteria, "in vitro fertili")) ~ 0,
#                                 (str_detect(cond_combo, "ivf") | str_detect(cond_combo, "in vitro fertili")) ~ 0,
#                                 (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ 0,
#                                 (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
#                                  (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ 0,
#                                 (str_detect(criteria,"spermicid")) ~ 0,
#                                 TRUE ~ 1)) %>%
#   filter(pregfilter == 1 & max_age > 13) %>%
#   select(nct_id, brief_title, criteria) %>%
#   mutate(preg_manual = 1) %>% 
#   filter(!str_detect(criteria, "singleton") & !str_detect(criteria, "gestational (age|week)") & !str_detect(criteria, "c(ae|e)sarean") & 
#            !str_detect(criteria, "infertil(e|ity)") & !str_detect(criteria, "weeks' gestation")) %>%
#   write.csv(file.path(output_path, "/global_trials_handcheck_SAFETY.csv"))


## Checked all criteria where criteria string detect triggers but preg_enrolled == 0
# focal_trials_global <- focal_trials_global %>%
#   mutate(preg_policy = case_when((preg_criteria == 1 & preg_enrolled == 0 & childbearing_age == 1 & women_included == 1 &
#                                     (nct_id != "NCT05457972" & nct_id != "NCT03232918" & nct_id != "NCT02487797" & nct_id != "NCT00276900" & nct_id != "NCT03111316" & 
#                                        nct_id != "NCT03074695" & nct_id != "NCT03556761" & nct_id != "NCT02902172" & nct_id != "NCT03168178" & nct_id != "NCT00720291" &    
#                                        nct_id != "NCT00325026" & nct_id != "NCT00453141" & nct_id != "NCT00466128" & nct_id != "NCT00442676" & nct_id != "NCT03714880" & 
#                                        nct_id != "NCT04417595" & nct_id != "NCT00504465" & nct_id != "NCT02469519" & nct_id != "NCT02221830" & nct_id != "NCT03801252" & 
#                                        nct_id != "NCT05370820" & nct_id != "NCT03584854" & nct_id != "NCT05097326" & nct_id != "NCT00879190" & nct_id != "NCT05232994" &
#                                        nct_id != "NCT03976037" & nct_id != "NCT00617097" & nct_id != "NCT00779467" & nct_id != "NCT02456662" & nct_id != "NCT01555931"))  ~ "Excluded",
#                                  TRUE ~ preg_policy),
#          preg_policy = ifelse(childbearing_age == 0 | women_included == 0, "Excluded", preg_policy),
#          preg_policy = ifelse(is.na(preg_policy), "Excluded", preg_policy)) %>%
#   mutate(preg_enrolled = ifelse(preg_policy == "Included" & preg_enrolled == 0 & childbearing_age == 1 & women_included == 1, 1, preg_enrolled))
}

# Assign enrollment from NCT_IDs
focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = case_when((nct_id == "NCT01276704" | nct_id == "NCT05934500" | nct_id == "NCT00302133" | nct_id == "NCT04153513" | nct_id == "NCT01441635" | nct_id == "NCT03387579" |
                                      nct_id  == "NCT03894215" | nct_id == "NCT04045821" | nct_id == "NCT04145518" | nct_id == "NCT00026286" | nct_id == "NCT01353209" | nct_id == "NCT00281671" |
                                      nct_id == "NCT03740737" | nct_id == "NCT03864068" | nct_id == "NCT04431960" | nct_id == "NCT00363909" | nct_id == "NCT00490802" | nct_id == "NCT04043455" |
                                      nct_id == "NCT00967005" | nct_id == "NCT03337490" | nct_id == "NCT04096326" | nct_id == "NCT00702949" | nct_id == "NCT04767373" | nct_id == "NCT02851472" |
                                      nct_id == "NCT05597722" | nct_id == "NCT01967017" | nct_id == "NCT02737436" | nct_id == "NCT01000623" | nct_id == "NCT03139240" | nct_id == "NCT00006401" |
                                      nct_id == "NCT03194906" | nct_id == "NCT03751657" | nct_id == "NCT03372382" | nct_id == "NCT01439945" | nct_id == "NCT01096784" | 
                                      nct_id == "NCT02044991" | nct_id == "NCT02141555" | nct_id == "NCT01011634" | nct_id == "NCT04153513" | nct_id == "NCT00004278") ~ 0,
                                   (nct_id == "NCT05069012" | nct_id == "NCT00151346" | nct_id == "NCT03117660" | 
                                      nct_id == "NCT01733212" | nct_id == "NCT05687344" | nct_id == "NCT04098874"| 
                                      nct_id == "NCT02377466" | nct_id == "NCT00830765" | nct_id == "NCT03961360" |
                                      nct_id == "NCT03152877" | nct_id == "NCT00957593" | nct_id == "NCT04496908" | nct_id == "NCT00610688" |
                                      nct_id == "NCT01869361" | nct_id == "NCT03954990" | nct_id == "NCT00641784" | nct_id == "NCT02536352" |
                                      nct_id == "NCT03171480" | nct_id == "NCT02565485" | nct_id == "NCT00402389" | nct_id == "NCT03348683" |
                                      nct_id == "NCT02454296" | nct_id == "NCT03022526" | nct_id == "NCT02115256" | nct_id == "NCT03202550" |
                                      nct_id == "NCT03305575" | nct_id == "NCT00306462" | nct_id == "NCT03106753" | nct_id == "NCT05068661" |
                                      nct_id == "NCT03140293" | nct_id == "NCT00377832" | nct_id == "NCT01402050" | nct_id == "NCT00719537" |
                                      nct_id == "NCT00871442" | nct_id == "NCT00201643" | nct_id == "NCT05047211" | nct_id == "NCT04578015" |
                                      nct_id == "NCT04479072" | nct_id == "NCT05782816" | nct_id == "NCT01866488" | nct_id == "NCT02505984" |
                                      nct_id == "NCT00811057" | nct_id == "NCT05973747" | nct_id == "NCT02806024" | nct_id == "NCT00946088" | 
                                      nct_id == "NCT00771511" | nct_id == "NCT00115687" | nct_id == "NCT02141555" |
                                      nct_id =="NCT04294069" | nct_id == "NCT04704024" | nct_id == "NCT01011634" | nct_id == "NCT02277782" | 
                                      nct_id == "NCT03433040" | nct_id == "NCT01734161" | nct_id == "NCT02265965" | nct_id == "NCT00086177" |
                                      nct_id == "NCT01307839" | nct_id == "NCT02314728" | nct_id == "NCT04278651" | nct_id == "NCT00458003" |
                                      nct_id == "NCT04158830" | nct_id == "NCT03335293" | nct_id == "NCT03640507" | nct_id == "NCT03567707" |
                                      nct_id == "NCT00468520" | nct_id == "NCT02571439" | nct_id == "NCT00787176" | nct_id == "NCT02213094" |
                                      nct_id == "NCT01828697" | nct_id == "NCT04615351" | nct_id == "NCT02960113" | nct_id == "NCT00432991" |
                                      nct_id == "NCT03105661" | nct_id == "NCT00293735" | nct_id == "NCT00615550" | nct_id == "NCT05692245" |
                                      nct_id == "NCT03117660" | nct_id == "NCT00743210" | nct_id == "NCT02247726" | nct_id == "NCT02487771" |
                                      nct_id == "NCT01216410" | nct_id == "NCT01566630" | nct_id == "NCT01621230" | nct_id == "NCT02872935" |
                                      nct_id == "NCT01840228" | nct_id == "NCT02573597" | nct_id == "NCT04908982" | nct_id == "NCT03052270" |
                                      nct_id == "NCT05132829" | nct_id == "NCT02101047" | nct_id == "NCT00194987" | nct_id == "NCT02408315" |
                                      nct_id == "NCT05487196" | nct_id == "NCT00404768" | nct_id == "NCT00762554" | nct_id == "NCT01329016" |
                                      nct_id == "NCT00163020" | nct_id == "NCT03029702" | nct_id == "NCT02509312" | nct_id == "NCT03918850" |
                                      nct_id == "NCT06036446" | nct_id == "NCT01801475" | nct_id == "NCT01733212" | nct_id == "NCT05676476" |
                                      nct_id == "NCT01812239" | nct_id == "NCT03245970" | nct_id == "NCT02121184" | nct_id == "NCT01519765" |
                                      nct_id == "NCT00583011" | nct_id == "NCT05912517" | nct_id == "NCT00514618" | nct_id == "NCT04349124" |
                                      nct_id == "NCT04532801" | nct_id == "NCT05069012" | nct_id == "NCT00151346" | nct_id == "NCT03117660" | 
                                      nct_id == "NCT01733212" | nct_id == "NCT00115687" | nct_id == "NCT00135707" | nct_id == "NCT03176459" |
                                      nct_id == "NCT02913495" | nct_id == "NCT01472549" | nct_id == "NCT00153517" | nct_id == "NCT02044991" | 
                                      nct_id == "NCT00093938" | nct_id == "NCT00133029" | nct_id == "NCT06029673" | nct_id == "NCT03677830" | 
                                      nct_id == "NCT02956616" | nct_id == "NCT03176459" | nct_id == "NCT02063568" | nct_id == "NCT00439374" | 
                                      nct_id == "NCT01862991" | nct_id == "NCT04232306" | nct_id == "NCT00724594" | nct_id == "NCT01047748" | 
                                      nct_id == "NCT03377595" | nct_id == "NCT01775605" | nct_id == "NCT02490345" | nct_id == "NCT03387579" |
                                      nct_id == "NCT03139240" | nct_id == "NCT03680339" | nct_id == "NCT04401839" | nct_id == "NCT04117243" |
                                      nct_id == "NCT03714880" | nct_id == "NCT02013960" | nct_id == "NCT00014989" | nct_id == "NCT03927807" |
                                      nct_id == "NCT02626299" | nct_id == "NCT03805945" | nct_id == "NCT02048098") ~ 1,
                                   (nct_id != "NCT03735433" & nct_id != "NCT00011362" & nct_id != "NCT04379518" & nct_id != "NCT00932321" & nct_id != "NCT02755090" & nct_id != "NCT01224509" & nct_id != "NCT00186082" &
                                      nct_id != "NCT04455958" & nct_id != "NCT00065858" & nct_id != "NCT01959464" & nct_id != "NCT01286051" & nct_id != "NCT03460756" & nct_id != "NCT03228394" & nct_id != "NCT03878446" & 
                                      nct_id != "NCT00337792" & nct_id != "NCT00005775" & nct_id != "NCT02447029" & nct_id != "NCT04830735" & nct_id != "NCT01857310" & nct_id != "NCT03785366" & nct_id != "NCT04665115" & 
                                      nct_id != "NCT04532372" & nct_id != "NCT00520455" & nct_id != "NCT00487084" & nct_id != "NCT01484015" & nct_id != "NCT01539720" & nct_id != "NCT01044862" & nct_id != "NCT05695352" &
                                      nct_id != "NCT00357526" & nct_id != "NCT02817464" & nct_id != "NCT00068861" & nct_id != "NCT00324324" & nct_id != "NCT00003702" & preg_enrolled == 0 & preg_condition == 1) ~ 1,
                                   (preg_criteria == 1 & preg_enrolled == 0 & childbearing_age == 1 & women_included == 1 &
                                      (nct_id != "NCT05457972" & nct_id != "NCT03232918" & nct_id != "NCT02487797" & nct_id != "NCT00276900" & nct_id != "NCT03111316" & 
                                         nct_id != "NCT03074695" & nct_id != "NCT03556761" & nct_id != "NCT02902172" & nct_id != "NCT03168178" & nct_id != "NCT00720291" &    
                                         nct_id != "NCT00325026" & nct_id != "NCT00453141" & nct_id != "NCT00466128" & nct_id != "NCT00442676" & nct_id != "NCT03714880" & 
                                         nct_id != "NCT04417595" & nct_id != "NCT00504465" & nct_id != "NCT02469519" & nct_id != "NCT02221830" & nct_id != "NCT03801252" & 
                                         nct_id != "NCT05370820" & nct_id != "NCT03584854" & nct_id != "NCT05097326" & nct_id != "NCT00879190" & nct_id != "NCT05232994" &
                                         nct_id != "NCT03976037" & nct_id != "NCT00617097" & nct_id != "NCT00779467" & nct_id != "NCT02456662" & nct_id != "NCT01555931")) ~ 0,
                                   TRUE ~ preg_enrolled)) 

## Assign enrollment from global handchecks
focal_trials_global <- focal_trials_global %>%
  left_join(read.csv(file.path(output_path, "/global_trials_handcheck.csv")) %>% select(nct_id, preg_manual),
            by = c("nct_id")) %>%
  mutate(preg_enrolled = case_when(is.na(preg_manual) ~ preg_enrolled,
                                   preg_manual == 1  ~ 1,
                                   preg_manual == 0 ~ 0,
                                   TRUE ~ preg_enrolled)) %>%
  select(-c(`preg_manual`))


## Assign to non-enrolling if doesn't enroll women of childbearing age
focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = ifelse(childbearing_age == 1 & women_included == 1, preg_enrolled, 0))



#### Final round of potential false positives ####
focal_trials_global <- focal_trials_global 
## Handcheck all pregnant studies
    ## that weren't previously hand checked and don't contain key terms
# focal_trials_global %>%
#   mutate(key_terms = case_when(str_detect(cond_combo, "pregnan(cy|t)") ~ 1,
#                              str_detect(criteria, "singleton") ~ 1,
#                              str_detect(criteria, "paturient") ~ 1,
#                              str_detect(criteria, "gestational (age|week)") ~ 1,
#                              str_detect(criteria, "c(ae)sarean") ~ 1,
#                              str_detect(criteria, "weeks' gestation") ~ 1,
#                              max_age <= 13 ~ 1,
#                              (str_detect(criteria, "(abortion|termination)") | str_detect(criteria, "non(-|)viable fetus") |
#                                 str_detect(criteria, "no fetal heartbeat") | str_detect(criteria, "undesired pregnancy")) ~ 1,
#                              (str_detect(cond_combo, "(abortion|terminiation)") | str_detect(cond_combo, "non(-|)viable fetus") |
#                                 str_detect(cond_combo, "no fetal heartbeat") | str_detect(cond_combo, "undesired pregnancy")) ~ 1,
#                              (str_detect(criteria, "ivf") | str_detect(criteria, "in vitro fertili")) ~ 1,
#                              (str_detect(cond_combo, "ivf") | str_detect(cond_combo, "in vitro fertili")) ~ 1,
#                              (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ 1,
#                              (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
#                                  (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ 1,
#                              (str_detect(criteria,"spermicid")) ~ 1,
#                              str_detect(criteria, "infertil(e|ity)") ~ 1,
#                              str_detect(cond_combo, "infertil(e|ity)") ~ 1,
#                              str_detect(criteria, "infertil(e|ity)") ~ 1,
#                              str_detect(criteria, "post(-|)partum") ~ 1,
#                              str_detect(cond_combo, "labor") ~ 1,
#                              str_detect(cond_combo, "cesarean") ~ 1,
#                              TRUE ~ 0)) %>%
#   filter(preg_enrolled == 1 & !(nct_id %in% checked_trials$nct_id) & childbearing_age == 1 & women_included == 1 & key_terms == 0) %>%
#   select(nct_id, criteria, cond_combo) %>%
#   mutate(preg_manual = 1) %>%
#   write.csv(file.path(output_path, "/falsepos_candidates_SAFETY.csv"))


#### Final round of potential false negatives ####

## Handcheck non-pregnant studies with any pregnant indicators == 1
    ## that weren't previously hand checked and don't contain key terms
# focal_trials_global %>%
#   mutate(key_terms = case_when(str_detect(cond_combo, "pregnan(cy|t)") ~ 1,
#                              str_detect(criteria, "singleton") ~ 1,
#                              str_detect(criteria, "paturient") ~ 1,
#                              str_detect(criteria, "gestational (age|week)") ~ 1,
#                              str_detect(criteria, "c(ae)sarean") ~ 1,
#                              str_detect(criteria, "weeks' gestation") ~ 1,
#                              max_age <= 13 ~ 1,
#                              (str_detect(criteria, "(abortion|termination)") | str_detect(criteria, "non(-|)viable fetus") |
#                                 str_detect(criteria, "no fetal heartbeat") | str_detect(criteria, "undesired pregnancy")) ~ 1,
#                              (str_detect(cond_combo, "(abortion|terminiation)") | str_detect(cond_combo, "non(-|)viable fetus") |
#                                 str_detect(cond_combo, "no fetal heartbeat") | str_detect(cond_combo, "undesired pregnancy")) ~ 1,
#                              (str_detect(criteria, "ivf") | str_detect(criteria, "in vitro fertili")) ~ 1,
#                              (str_detect(cond_combo, "ivf") | str_detect(cond_combo, "in vitro fertili")) ~ 1,
#                              (str_detect(criteria, "contracept(ion|ive)") | str_detect(criteria, "birth control")) ~ 1,
#                              (str_detect(criteria,"(method of|methods of|form of|effective|use) (|an )(|adequate |effective |appropriate )
#                                  (birth control|contraception|contraceptive|avoiding pregnancy)")) ~ 1,
#                              (str_detect(criteria,"spermicid")) ~ 1,
#                              str_detect(criteria, "infertil(e|ity)") ~ 1,
#                              str_detect(cond_combo, "infertil(e|ity)") ~ 1,
#                              str_detect(criteria, "infertil(e|ity)") ~ 1,
#                              str_detect(criteria, "post(-|)partum") ~ 1,
#                              str_detect(cond_combo, "labor") ~ 1,
#                              str_detect(cond_combo, "cesarean") ~ 1,
#                              TRUE ~ 0)) %>%
#   filter(preg_sums > 0 & preg_enrolled == 0 & !(nct_id %in% checked_trials$nct_id) & key_terms == 0 & childbearing_age == 1 & women_included == 1 & key_terms == 0) %>%
#   select(nct_id, criteria, cond_combo) %>%
#   mutate(preg_manual = 0) %>%
#   write.csv(file.path(output_path, "/falseneg_candidates_SAFETY.csv"))


#### Merge on false pos/neg candidate checks and re-assign where necessary
focal_trials_global <- focal_trials_global %>%
  left_join(read.csv(file.path(output_path, "/falsepos_candidates.csv")) %>% select(nct_id, preg_manual),
            by = c("nct_id")) %>%
  mutate(preg_enrolled = case_when(preg_enrolled == 1 & preg_manual == 0 ~ 0,
                                   TRUE ~ preg_enrolled)) %>%
  select(-c(`preg_manual`))
  
focal_trials_global <- focal_trials_global %>%
  left_join(read.csv(file.path(output_path, "/falseneg_candidates.csv")) %>% select(nct_id, preg_manual),
            by = c("nct_id")) %>%
  mutate(preg_enrolled = case_when(preg_enrolled == 0 & preg_manual == 1 ~ 1,
                                   TRUE ~ preg_enrolled)) %>%
  select(-c(`preg_manual`))



#### Indicate whether study explicitly barres pregnancy
focal_trials_global <- focal_trials_global %>%
  mutate(preg_policy = case_when(preg_enrolled == 1 ~ "Enrolled",
                                 (preg_enrolled == 0 & (women_included == 0 | childbearing_age == 0)) ~ "Excluded",
                                 (preg_enrolled == 0 & is.na(preg_criteria)) ~ "NotMentioned",
                                 (preg_enrolled == 0 & preg_criteria == 0) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(exclusion, "pregnan")) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(criteria, "post(-|)menop") & !str_detect(criteria, "pre(-|)menop")) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(criteria, "surgical(-| |ly|ly-)steril(e|ized|ization)")) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(criteria, "non(-|)child(-|)bearing potential")) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(criteria, "abortion")) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(cond_combo, "abortion")) ~ "Excluded",
                                 (preg_enrolled == 0 & str_detect(criteria, "termination")) ~ "Excluded",
                                 TRUE ~ NA))


#### Another handcheck for preg_policy == NA cases, some preg_enrolled re-sorting ####
# focal_trials_global %>%
#   filter(is.na(preg_policy)) %>%
#   select(nct_id, criteria, cond_combo) %>%
#   mutate(preg_manual = 0) %>%
#   write.csv(file.path(output_path, "/handcheck_policyNAs_SAFETY.csv"))
  

focal_trials_global <- focal_trials_global %>%
  left_join(read.csv(file.path(output_path, "/handcheck_policyNAs.csv")) %>% select(nct_id, preg_manual))

focal_trials_global <- focal_trials_global_ %>%
  mutate(preg_enrolled = case_when(preg_enrolled == 0 & preg_manual == 1 ~ 1,
                                   preg_manual == 0 ~ 0,
                                   TRUE ~ preg_enrolled))
  
focal_trials_global <- focal_trials_global %>%
  mutate(preg_policy = case_when(preg_enrolled == 1 ~ "Enrolled",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "pregnan(cy|t)") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "(infant|neonate|children)") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "gestation") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "birth control") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "contraception") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "child(|-| )bearing") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "(menopaus|menarche|infertile)") ~ "Excluded",
                                 preg_enrolled == 0 & preg_manual == 0 & str_detect(criteria, "cesarean") ~ "Excluded",
                                 TRUE ~ preg_policy))

#### Checked remaining NAs again, assigning to NotMentioned
# focal_trials_global_ %>%
#   filter(is.na(preg_policy)) %>%
#   select(nct_id, criteria, cond_combo, preg_enrolled, preg_manual) %>%
#   View()



#### Handful of re-sorts found using sampler below and reading all US preg-enrolling trials (again)
focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = case_when(nct_id == "NCT00457925" ~ 0,
                                   nct_id == "NCT01863706" ~ 0,
                                   nct_id == "NCT05360576" ~ 0,
                                   nct_id == "NCT04012177" ~ 0,
                                   nct_id == "NCT03547284" ~ 0,
                                   nct_id == "NCT03547284" ~ 0,
                                   nct_id == "NCT01695850" ~ 0,
                                   nct_id == "NCT04175990" ~ 0,
                                   nct_id == "NCT00570440" ~ 0,
                                   nct_id == "NCT05868109" ~ 0,
                                   nct_id == "NCT02379650" ~ 0,
                                   nct_id == "NCT03714880" ~ 0,
                                   nct_id == "NCT01671410" ~ 0,
                                   nct_id == "NCT00115687" ~ 0,
                                   nct_id == "NCT00009620" ~ 0,
                                   nct_id == "NCT00299000" ~ 0,
                                   nct_id == "NCT00412074" ~ 0,
                                   nct_id == "NCT01047748" ~ 0,
                                   nct_id == "NCT01862991" ~ 0,
                                   nct_id == "NCT01422226" ~ 0,
                                   nct_id == "NCT01708330" ~ 0,
                                   TRUE ~ preg_enrolled),
         preg_policy = case_when((preg_policy == "Enrolled" & preg_enrolled == 0) ~ "Excluded",
                                 TRUE ~ preg_policy))


focal_trials_global <- focal_trials_global %>%
  mutate(preg_policy = case_when(nct_id == "NCT01286051" ~ "Excluded",
                                 nct_id == "NCT00068861" ~ "Excluded",
                                 TRUE ~ preg_policy))



focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = case_when(nct_id == "NCT04830735" ~ 0,
                                   TRUE ~ preg_enrolled),
         preg_policy = case_when(nct_id == "NCT04830735" ~ "NotMentioned",
                                 TRUE ~ preg_policy))


focal_trials_global <- focal_trials_global %>%
  mutate(preg_enrolled = case_when(child == TRUE & adult == FALSE ~ 0,
                                   TRUE ~ preg_enrolled),
         preg_policy = case_when((preg_policy == "Enrolled" & preg_enrolled == 0) ~ "Excluded",
                                 TRUE ~ preg_policy))


focal_trials_global %>%
  select(preg_enrolled) %>%
  table()

focal_trials_global %>%
  filter(usa == 1) %>%
  select(preg_enrolled) %>%
  table()


focal_trials_global %>%
  select(preg_policy) %>%
  table()

focal_trials_global %>%
  filter(usa == 1) %>%
  select(preg_policy) %>%
  table()



#### Sampler ####

# Enrolled
included_sample <- sample(focal_trials_global %>% filter(preg_policy == "Enrolled") %>% pull(nct_id), 20)

focal_trials_global %>%
  filter(preg_policy == "Enrolled" & women_included == 1 & childbearing_age == 1) %>%
  filter(nct_id %in% included_sample) %>%
  select(nct_id, criteria, cond_combo, brief_title) %>%
  View()

# Excluded
excluded_sample <- sample(focal_trials_global %>% filter(preg_policy == "Excluded") %>% pull(nct_id), 20)

focal_trials_global %>%
  filter(preg_policy == "Excluded" & women_included == 1 & childbearing_age == 1) %>%
  filter(nct_id %in% excluded_sample) %>%
  select(nct_id, criteria, cond_combo, brief_title) %>%
  View()

# Not mentioned
notmentioned_sample <- sample(focal_trials_global %>% filter(preg_policy == "NotMentioned") %>% pull(nct_id), 20)

focal_trials_global %>%
  filter(preg_policy == "NotMentioned" & women_included == 1 & childbearing_age == 1) %>%
  filter(nct_id %in% notmentioned_sample) %>%
  select(nct_id, criteria, cond_combo, brief_title) %>%
  View()





#### Output pregnancy-enrolling/excluding studies for checks ####

focal_trials_global %>%
  filter(preg_policy == "Enrolled" & women_included == 1 & childbearing_age == 1) %>%
  select(brief_title, nct_id, criteria, cond_combo) %>%
  write.csv(file.path(output_path, "/preg_enrolled_021324.csv"))

focal_trials_global %>%
  filter(preg_policy == "Excluded" & women_included == 1 & childbearing_age == 1) %>%
  select(brief_title, nct_id, criteria, cond_combo) %>%
  write.csv(file.path(output_path, "/preg_excluded_021324.csv"))

focal_trials_global %>%
  filter(preg_policy == "NotMentioned" & women_included == 1 & childbearing_age == 1) %>%
  select(brief_title, nct_id, criteria, cond_combo) %>%
  write.csv(file.path(output_path, "/preg_notmentioned_021324.csv"))



#### Indicate pregnancy-related condition
focal_trials_global <- focal_trials_global %>%
  mutate(preg_only = case_when((preg_enrolled == 1 & str_detect(cond_combo, "pregnan(t|cy)")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "labo(|u)r")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "delivery")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "miscarriage")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "fetal")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "cervical")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "infant")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "newborn")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "abortion")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "cesarean")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "c(-|)section")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "gestational")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "obstetric")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "preeclampsia")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "partum")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "post(|-| )operat")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "pregnancy( |-)(induced|related|complication)")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "pre(-|)(mature|term) (birth|delivery)")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "(in|of) pregnancy")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "rupture of membrane")) ~ 1,
                               (preg_enrolled == 1 & str_detect(criteria, "cesarean")) ~ 1,
                               (preg_enrolled == 1 & str_detect(criteria, "c(-|)section")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "natal")) ~ 1,
                               (preg_enrolled == 1 & str_detect(cond_combo, "preterm")) ~ 1,
                               TRUE ~ 0))

### Checks
focal_trials_global %>%
  filter(preg_enrolled == 1 & preg_only == 0 & usa == 1) %>%
  select(nct_id, brief_title, criteria, cond_combo, min_age, max_age) %>%
  write.csv(file.path(output_path, "/conditions_notonlypreg.csv"))



focal_trials_global %>%
  filter(preg_enrolled == 1 ) %>%
  select(preg_only) %>% table()


focal_trials_global %>%
  filter(preg_enrolled == 1 & usa ==1) %>%
  select(preg_only) %>% table()




#### Collapse groups, create group indicators ####
focal_trials_global <- focal_trials_global %>%
  mutate(primary_purpose = case_when(primary_purpose == "Prevention" ~ "Prevention",
                                     primary_purpose == "Treatment" ~ "Treatment",
                                     TRUE ~ "Other")) %>%
  mutate(intervention_model = case_when(intervention_model == "Parallel Assignment" ~ "Parallel Assignment",
                                        intervention_model == "Single Group Assignment" ~ "Single Group Assignment",
                                        TRUE ~ "Other")) %>%
  mutate(overall_status = case_when((overall_status == "Recruiting" |
                                       overall_status == "Enrolling by invitation" |
                                       overall_status == "Not yet recruiting") ~ "Not yet active",
                                    (overall_status == "Active, not recruiting") ~ "Active",
                                    (overall_status == "Completed") ~ "Completed",
                                    (overall_status == "Suspended" | 
                                       overall_status == "Terminated" |
                                       overall_status == "Withdrawn") ~ "Suspended/terminated/withdrawn",
                                    TRUE ~ overall_status)) %>%
  mutate(masking = case_when(masking == "Double" ~ "Double+",
                             masking == "Triple" ~ "Double+",
                             masking == "Quadruple" ~ "Double+",
                             TRUE ~ masking))


focal_trials_global <- focal_trials_global %>%
  mutate(int_single = ifelse(intervention_model == "Single Group Assignment",1,0),
         int_parallel = ifelse(intervention_model == "Parallel Assignment",1,0),
         int_other = ifelse(intervention_model == "Other",1,0),
         mask_none = ifelse(masking == "None (Open Label)",1,0),
         mask_single = ifelse(masking == "Single",1,0),
         mask_doubleplus = ifelse(masking == "Double+",1,0),
         prevention = ifelse(primary_purpose == "Prevention",1,0),
         treatment = ifelse(primary_purpose == "Treatment",1,0),
         pp_other = ifelse(primary_purpose == "Other",1,0),
         stat_preactive = ifelse(overall_status == "Not yet active",1,0),
         stat_active = ifelse(overall_status == "Active",1,0),
         stat_completed = ifelse(overall_status == "Completed",1,0),
         stat_terminated = ifelse(overall_status == "Suspended/terminated/withdrawn",1,0))




#### Date range ####
focal_trials_global <- focal_trials_global %>%
  filter(yr_submitted >= 2001 & yr_submitted <= 2023)

#### Save ####

# focal_trials_global <- read.csv(file.path(data_path, "/focal_trials_global.csv"))







#### COVID ####
focal_trials_global <- focal_trials_global %>%
  mutate(covid = case_when(str_detect(cond_combo, "covid") ~ 1,
                           str_detect(cond_combo, "coronavirus") ~ 1,
                           str_detect(cond_combo, "sars-cov-2") ~ 1,
                           str_detect(cond_combo, "cov-2") ~ 1,
                           TRUE ~ 0))

focal_trials_global %>%
  filter(yr_submitted >= 2020) %>%
  group_by(preg_enrolled, usa) %>%
  summarize(share = mean(covid))
  

write.csv(focal_trials_global, file.path(data_path, "/focal_trials_global.csv"))


focal_trials <- focal_trials_global %>%
  filter(usa == 1)

#### Surgically-sterile/post-menopausal women only studies ####
sspm_ncts <- focal_trials %>%
  filter(women_included == 1 & childbearing_age == 1 & 
           (str_detect(criteria, "(surgical|surgically| )steril(e|ized|ization)") |
              str_detect(criteria, "menopaus") |
              str_detect(criteria, "non(-|)childbearing") |
              str_detect(criteria, "infertile")) &
           !str_detect(criteria, "pregnancy test") &
           !str_detect(criteria, "contracept(ion|ive)") &
           !str_detect(criteria, "birth control") &
           !str_detect(criteria, "pre(-|)menopaus")) %>%
  select(nct_id) 

# focal_trials %>%
#   filter(nct_id %in% sspm_ncts) %>%
#   write.csv(file.path(output_path, "/cbawomen_exclusions2.csv"))


# focal_trials %>% 
#   filter(women_included == 1 & childbearing_age == 1 & !(nct_id %in% sspm_ncts$nct_id) &
#            (str_detect(criteria, "hysterect") | str_detect(criteria, "oophorect")) &
#            !str_detect(criteria, "pregnancy test") &
#            !str_detect(criteria, "contracept(ion|ive)") &
#            !str_detect(criteria, "birth control") &
#            !str_detect(criteria, "pre(-|)menopaus")) %>%
#   select(nct_id, criteria) %>%
#   write.csv(file.path(output_path, "/hyst_ooph.csv"))

sspm <- read.csv(file.path(output_path, "/cbawomen_exclusions2.csv"))

focal_trials <- focal_trials %>%
  left_join(sspm %>% select(nct_id, sspm)) %>%
  mutate(sspm = ifelse(is.na(sspm),0,sspm),
         preg_enrolled = ifelse(sspm==1, 0,preg_enrolled))

focal_trials %>%
  select(sspm) %>%
  table()


write.csv(focal_trials, file.path(data_path, "/focal_trials.csv"))


# 
# 
# checked_trials <- focal_trials_global %>%
#   select(nct_id) %>% 
#   filter(nct_id == "NCT01276704" | nct_id == "NCT05934500" | nct_id == "NCT00302133" |
#            nct_id  == "NCT03894215" | nct_id == "NCT04045821" | nct_id == "NCT04145518" |
#            nct_id == "NCT03740737" | nct_id == "NCT03864068" | nct_id == "NCT04431960" |
#            nct_id == "NCT00967005" | nct_id == "NCT03337490" | nct_id == "NCT04096326" |
#            nct_id == "NCT05597722" | nct_id == "NCT01967017" | nct_id == "NCT02737436" |
#            nct_id == "NCT03194906" | nct_id == "NCT03751657" | nct_id == "NCT03372382" | 
#            nct_id == "NCT02044991" | nct_id == "NCT05687344" | nct_id == "NCT04098874"| nct_id == "NCT02377466" |
#            nct_id == "NCT00830765" | nct_id == "NCT03961360" | nct_id == "NCT03152877" | nct_id == "NCT00957593" | 
#            nct_id == "NCT04496908" | nct_id == "NCT00610688" |
#            nct_id == "NCT01869361" | nct_id == "NCT03954990" | nct_id == "NCT00641784" | nct_id == "NCT02536352" |
#            nct_id == "NCT03171480" | nct_id == "NCT02565485" | nct_id == "NCT00402389" | nct_id == "NCT03348683" |
#            nct_id == "NCT02454296" | nct_id == "NCT03022526" | nct_id == "NCT02115256" | nct_id == "NCT03202550" |
#            nct_id == "NCT03305575" | nct_id == "NCT00306462" | nct_id == "NCT03106753" | nct_id == "NCT05068661" |
#            nct_id == "NCT03140293" | nct_id == "NCT00377832" | nct_id == "NCT01402050" | nct_id == "NCT00719537" |
#            nct_id == "NCT00871442" | nct_id == "NCT00201643" | nct_id == "NCT05047211" | nct_id == "NCT04578015" |
#            nct_id == "NCT04479072" | nct_id == "NCT05782816" | nct_id == "NCT01866488" | nct_id == "NCT02505984" |
#            nct_id == "NCT00811057" | nct_id == "NCT05973747" | nct_id == "NCT02806024" |
#            nct_id == "NCT00946088" | nct_id == "NCT00771511" | nct_id == "NCT00115687" | nct_id == "NCT02141555" |
#            nct_id =="NCT04294069" | nct_id == "NCT04704024" | nct_id == "NCT01011634" | nct_id == "NCT02277782" | 
#            nct_id == "NCT03433040" | nct_id == "NCT01734161" | nct_id == "NCT02265965" | nct_id == "NCT00086177" |
#            nct_id == "NCT01307839" | nct_id == "NCT02314728" | nct_id == "NCT04278651" | nct_id == "NCT00458003" |
#            nct_id == "NCT04158830" | nct_id == "NCT03335293" | nct_id == "NCT03640507" | nct_id == "NCT03567707" |
#            nct_id == "NCT00468520" | nct_id == "NCT02571439" | nct_id == "NCT00787176" | nct_id == "NCT02213094" |
#            nct_id == "NCT01828697" | nct_id == "NCT04615351" | nct_id == "NCT02960113" | nct_id == "NCT00432991" |
#            nct_id == "NCT03105661" | nct_id == "NCT00293735" | nct_id == "NCT00615550" | nct_id == "NCT05692245" |
#            nct_id == "NCT03117660" | nct_id == "NCT00743210" | nct_id == "NCT02247726" | nct_id == "NCT02487771" |
#            nct_id == "NCT01216410" | nct_id == "NCT01566630" | nct_id == "NCT01621230" | nct_id == "NCT02872935" |
#            nct_id == "NCT01840228" | nct_id == "NCT02573597" | nct_id == "NCT04908982" | nct_id == "NCT03052270" |
#            nct_id == "NCT05132829" | nct_id == "NCT02101047" | nct_id == "NCT00194987" | nct_id == "NCT02408315" |
#            nct_id == "NCT05487196" | nct_id == "NCT00404768" | nct_id == "NCT00762554" | nct_id == "NCT01329016" |
#            nct_id == "NCT00163020" | nct_id == "NCT03029702" | nct_id == "NCT02509312" | nct_id == "NCT03918850" |
#            nct_id == "NCT06036446" | nct_id == "NCT01801475" | nct_id == "NCT01733212" | nct_id == "NCT05676476" |
#            nct_id == "NCT01812239" | nct_id == "NCT03245970" | nct_id == "NCT02121184" | nct_id == "NCT01519765" |
#            nct_id == "NCT00583011" | nct_id == "NCT05912517" | nct_id == "NCT00514618" | nct_id == "NCT04349124" |
#            nct_id == "NCT04532801" | nct_id == "NCT05069012" | nct_id == "NCT00151346" | nct_id == "NCT03117660" | 
#            nct_id == "NCT01733212" | nct_id == "NCT00115687" | nct_id == "NCT00135707" | nct_id == "NCT03176459" |
#            nct_id == "NCT02141555" | nct_id == "NCT01011634" | nct_id == "NCT04153513" | nct_id == "NCT03735433" | 
#            nct_id == "NCT00011362" | nct_id == "NCT04379518" | nct_id == "NCT00932321" | nct_id == "NCT02755090" | 
#            nct_id == "NCT01224509" | nct_id == "NCT00186082" | nct_id == "NCT04455958" | nct_id == "NCT00065858" | 
#            nct_id == "NCT01959464" | nct_id == "NCT01286051" | nct_id == "NCT03460756" | nct_id == "NCT03228394" | 
#            nct_id == "NCT03878446" | nct_id == "NCT00337792" | nct_id == "NCT00005775" | nct_id == "NCT02447029" | 
#            nct_id == "NCT04830735" | nct_id == "NCT01857310" | nct_id == "NCT03785366" | nct_id == "NCT04665115" | 
#            nct_id == "NCT04532372" | nct_id == "NCT00520455" | nct_id == "NCT00487084" | nct_id == "NCT01484015" | 
#            nct_id == "NCT01539720" | nct_id == "NCT01044862" | nct_id == "NCT05695352" | nct_id == "NCT00357526" | 
#            nct_id == "NCT02817464" | nct_id == "NCT00068861" | nct_id == "NCT00324324" | nct_id == "NCT00003702" | 
#            nct_id == "NCT02913495" | nct_id == "NCT01472549" | nct_id == "NCT00153517" | nct_id == "NCT02044991" | 
#            nct_id == "NCT00093938" | nct_id == "NCT00133029" | nct_id == "NCT06029673" | nct_id == "NCT01775605" | 
#            nct_id == "NCT02490345" | nct_id == "NCT03387579" | nct_id == "NCT03139240" | nct_id == "NCT05457972" | 
#            nct_id == "NCT03232918" | nct_id == "NCT02487797" | nct_id == "NCT00276900" | nct_id == "NCT03111316" | 
#            nct_id == "NCT03677830" | nct_id == "NCT02956616" | nct_id == "NCT03176459" | nct_id == "NCT02063568" | 
#            nct_id == "NCT00439374" | nct_id == "NCT01862991" | nct_id == "NCT04232306" | nct_id == "NCT00724594" | 
#            nct_id == "NCT01047748"  | nct_id == "NCT03377595"| nct_id == "NCT03074695" | nct_id == "NCT03556761" | 
#            nct_id == "NCT02902172" | nct_id == "NCT03168178" | nct_id == "NCT00720291" | 
#            nct_id == "NCT00325026" | nct_id == "NCT00453141" | nct_id == "NCT00466128" | nct_id == "NCT00442676" | nct_id == "NCT03714880" | 
#            nct_id == "NCT04417595" | nct_id == "NCT00504465" | nct_id == "NCT02469519" | nct_id == "NCT02221830" | nct_id == "NCT03801252" | 
#            nct_id == "NCT05370820" | nct_id == "NCT03584854" | nct_id == "NCT05097326" | nct_id == "NCT00879190" | nct_id == "NCT05232994" |
#            nct_id == "NCT03976037" | nct_id == "NCT00617097" | nct_id == "NCT00779467" | nct_id == "NCT02456662" | nct_id == "NCT01555931") %>%
#   rbind(read.csv(file.path(output_path, "/global_trials_handcheck.csv")) %>% select(nct_id)) %>%
#   unique()
# 
# 
# 
# 
# 



